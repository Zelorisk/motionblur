package com.chrismod.motionblur.mixin;

import com.chrismod.motionblur.MotionBlurMod;
import com.chrismod.motionblur.render.MotionBlurRenderer;
import net.minecraft.class_310;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public class GameRendererMixin {

    @Inject(method = "render", at = @At("HEAD"))
    private void onRenderStart(
        class_9779 tickCounter,
        boolean tick,
        CallbackInfo ci
    ) {
        class_310 client = class_310.method_1551();
        MotionBlurRenderer renderer = MotionBlurMod.getRenderer();
        if (renderer != null) {
            renderer.onFrameStart(client);
        }
    }

    @Inject(
        method = "render",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/gui/hud/InGameHud;render(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V"
        )
    )
    private void onPreHud(
        class_9779 tickCounter,
        boolean tick,
        CallbackInfo ci
    ) {
        class_310 client = class_310.method_1551();
        MotionBlurRenderer renderer = MotionBlurMod.getRenderer();
        if (renderer != null) {
            renderer.renderMotionBlur(client);
        }
    }
}
