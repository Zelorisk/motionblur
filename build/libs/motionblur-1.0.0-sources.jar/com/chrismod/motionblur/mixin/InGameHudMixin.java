package com.chrismod.motionblur.mixin;

import com.chrismod.motionblur.MotionBlurMod;
import com.chrismod.motionblur.config.MotionBlurConfig;
import com.chrismod.motionblur.render.MotionBlurRenderer;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class InGameHudMixin {

    @Inject(method = "render", at = @At("TAIL"))
    private void onHudRender(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        MotionBlurConfig config = MotionBlurMod.getConfig();
        MotionBlurRenderer renderer = MotionBlurMod.getRenderer();

        if (config == null || renderer == null || !config.showHud || !config.enabled) return;

        String typeNames = switch (config.blurType) {
            case 1 -> "Accum";
            case 2 -> "Vel";
            case 3 -> "Enh";
            default -> "?";
        };

        String hudText = "MB: " + typeNames + " | " + String.format("%.0f%%", config.intensity * 100)
                + " | S" + config.sampleCount;

        context.method_25303(
                net.minecraft.class_310.method_1551().field_1772,
                hudText,
                2, 2,
                0xFFFFD700
        );
    }
}
