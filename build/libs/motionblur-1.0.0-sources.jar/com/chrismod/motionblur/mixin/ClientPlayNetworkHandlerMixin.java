package com.chrismod.motionblur.mixin;

import com.chrismod.motionblur.MotionBlurMod;
import net.minecraft.class_2708;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class ClientPlayNetworkHandlerMixin {

    @Inject(method = "onPlayerPositionLook", at = @At("HEAD"))
    private void onTeleport(class_2708 packet, CallbackInfo ci) {
        if (MotionBlurMod.getRenderer() != null) {
            MotionBlurMod.getRenderer().onTeleport();
        }
    }
}
