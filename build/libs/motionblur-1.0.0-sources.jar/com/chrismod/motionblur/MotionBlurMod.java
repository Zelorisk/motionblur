package com.chrismod.motionblur;

import com.chrismod.motionblur.config.MotionBlurConfig;
import com.chrismod.motionblur.gui.MotionBlurScreen;
import com.chrismod.motionblur.render.MotionBlurRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientWorldEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MotionBlurMod implements ClientModInitializer {

    public static final String MOD_ID = "motionblur";
    public static final String MOD_VERSION = "1.0.0";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static MotionBlurConfig config;
    private static MotionBlurRenderer renderer;
    public static class_304 toggleKeybind;
    public static class_304 guiKeybind;

    @Override
    public void onInitializeClient() {
        config = MotionBlurConfig.load();
        applyRefreshRateDefaults(config);
        renderer = new MotionBlurRenderer(config);

        class_304.class_11900 category = class_304.class_11900.method_74698(
            class_2960.method_60655(MOD_ID, "keys")
        );

        toggleKeybind = KeyBindingHelper.registerKeyBinding(
            new class_304(
                "motionblur.keybind.toggle",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_UNKNOWN,
                category
            )
        );

        guiKeybind = KeyBindingHelper.registerKeyBinding(
            new class_304(
                "motionblur.keybind.gui",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_B,
                category
            )
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKeybind.method_1436()) {
                config.enabled = !config.enabled;
                MotionBlurConfig.save(config);
            }
            while (guiKeybind.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(new MotionBlurScreen(null, config));
                }
            }
        });

        ClientWorldEvents.AFTER_CLIENT_WORLD_CHANGE.register(
            (client, world) -> {
                if (renderer != null) renderer.onWorldUnload();
            }
        );

        ResourceManagerHelper.get(
            class_3264.field_14188
        ).registerReloadListener(
            new SimpleSynchronousResourceReloadListener() {
                @Override
                public class_2960 getFabricId() {
                    return class_2960.method_60655(MOD_ID, "pipeline_invalidate");
                }

                @Override
                public void method_14491(class_3300 manager) {
                    if (renderer != null) renderer.onWorldUnload();
                }
            }
        );

        LOGGER.info("MotionBlur initialized");
    }

    private static void applyRefreshRateDefaults(MotionBlurConfig cfg) {
        if (!cfg.refreshRateOptimization) return;
        try {
            class_310 client = class_310.method_1551();
            if (
                client != null &&
                client.method_22683() != null &&
                client.method_22683().method_20831() != null
            ) {
                int refreshRate = client
                    .method_22683()
                    .method_20831()
                    .method_1617()
                    .method_1671();
                if (refreshRate >= 120) {
                    cfg.sampleCount = Math.max(cfg.sampleCount, 9);
                    cfg.intensity = Math.min(cfg.intensity, 0.55f);
                } else {
                    cfg.sampleCount = Math.min(cfg.sampleCount, 7);
                }
            }
        } catch (Exception e) {
            LOGGER.warn(
                "Could not detect monitor refresh rate, using config defaults"
            );
        }
    }

    public static MotionBlurConfig getConfig() {
        return config;
    }

    public static MotionBlurRenderer getRenderer() {
        return renderer;
    }
}
