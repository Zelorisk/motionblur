package com.chrismod.motionblur.gui;

import com.chrismod.motionblur.MotionBlurMod;
import com.chrismod.motionblur.config.MotionBlurConfig;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class MotionBlurScreen extends class_437 {

    private static final int BG_COLOR = 0xD0101010;
    private static final int HEADER_BG = 0xFF1A1A1A;
    private static final int ROW_HOVER = 0x22FFFFFF;
    private static final int YELLOW = 0xFFFFD700;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFF888888;
    private static final int CHECK_ON = 0xFFFFD700;
    private static final int CHECK_OFF = 0xFF555555;
    private static final int CHECK_FILL_ON = 0xFF2A2A00;
    private static final int PANEL_W = 240;
    private static final int ROW_H = 14;
    private static final int ROW_PAD = 3;
    private static final int HEADER_H = 20;
    private static final int FOOTER_H = 18;
    private static final int SIDE_PAD = 8;
    private static final int CORNER_R = 6;
    private static final int BORDER_COLOR = 0xFF303030;

    private final class_437 parent;
    private final MotionBlurConfig config;

    private int panelX;
    private int panelY;
    private int panelH;

    private final List<Row> rows = new ArrayList<>();
    private SliderRow draggedSlider = null;
    private int draggedSliderY = 0;

    public MotionBlurScreen(class_437 parent, MotionBlurConfig config) {
        super(class_2561.method_43470("MotionBlur v" + MotionBlurMod.MOD_VERSION));
        this.parent = parent;
        this.config = config;
    }

    @Override
    protected void method_25426() {
        rows.clear();

        rows.add(new SectionRow("--- General ---"));
        rows.add(
            new ToggleRow(
                "Enabled",
                () -> config.enabled,
                v -> config.enabled = v
            )
        );
        rows.add(
            new CycleRow("Blur Type", this::blurTypeName, this::cycleBlurType)
        );
        rows.add(new SectionRow("--- Quality ---"));
        rows.add(
            new SliderRow(
                "Intensity",
                () -> config.intensity,
                v -> config.intensity = v,
                0.01f,
                1.0f,
                false
            )
        );
        rows.add(
            new SliderRow(
                "Sample Count",
                () -> (float) config.sampleCount,
                v -> config.sampleCount = Math.round(v),
                3f,
                15f,
                true
            )
        );
        rows.add(new SectionRow("--- Presets ---"));
        rows.add(
            new ButtonRow("Performance", () ->
                config.applyPreset(MotionBlurConfig.Preset.PERFORMANCE)
            )
        );
        rows.add(
            new ButtonRow("Balanced", () ->
                config.applyPreset(MotionBlurConfig.Preset.BALANCED)
            )
        );
        rows.add(
            new ButtonRow("Quality", () ->
                config.applyPreset(MotionBlurConfig.Preset.QUALITY)
            )
        );
        rows.add(
            new ButtonRow("Ultra", () ->
                config.applyPreset(MotionBlurConfig.Preset.ULTRA)
            )
        );
        rows.add(new SectionRow("--- Advanced ---"));
        rows.add(
            new ToggleRow(
                "Refresh Rate Opt.",
                () -> config.refreshRateOptimization,
                v -> config.refreshRateOptimization = v
            )
        );
        rows.add(
            new ToggleRow(
                "Camera Only Mode",
                () -> config.cameraOnlyMode,
                v -> config.cameraOnlyMode = v
            )
        );
        rows.add(
            new ToggleRow(
                "Glossy Mode",
                () -> config.glossyMode,
                v -> config.glossyMode = v
            )
        );
        rows.add(
            new ToggleRow(
                "CRT Mode",
                () -> config.crtMode,
                v -> config.crtMode = v
            )
        );
        rows.add(
            new ToggleRow(
                "Show HUD",
                () -> config.showHud,
                v -> config.showHud = v
            )
        );

        panelH =
            HEADER_H + rows.size() * (ROW_H + ROW_PAD) + ROW_PAD + FOOTER_H;
        panelX = (field_22789 - PANEL_W) / 2;
        panelY = (field_22790 - panelH) / 2;
    }

    @Override
    public void method_25420(class_332 ctx, int mx, int my, float delta) {
        ctx.method_25294(0, 0, field_22789, field_22790, 0x80000000);
    }

    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {
        method_25420(ctx, mx, my, delta);

        drawRoundedRect(
            ctx,
            panelX,
            panelY,
            PANEL_W,
            panelH,
            CORNER_R,
            BG_COLOR
        );
        drawRoundedRect(
            ctx,
            panelX,
            panelY,
            PANEL_W,
            HEADER_H,
            CORNER_R,
            HEADER_BG
        );
        ctx.method_25294(
            panelX,
            panelY + CORNER_R,
            panelX + PANEL_W,
            panelY + HEADER_H,
            HEADER_BG
        );
        drawRoundedBorder(
            ctx,
            panelX,
            panelY,
            PANEL_W,
            panelH,
            CORNER_R,
            BORDER_COLOR
        );

        ctx.method_25300(
            field_22793,
            "MotionBlur v" + MotionBlurMod.MOD_VERSION,
            panelX + PANEL_W / 2,
            panelY + (HEADER_H - 8) / 2,
            YELLOW
        );

        int ry = panelY + HEADER_H + ROW_PAD;
        for (Row row : rows) {
            row.render(ctx, panelX, ry, PANEL_W, mx, my);
            ry += ROW_H + ROW_PAD;
        }

        ctx.method_25300(
            field_22793,
            "Made by chris",
            panelX + PANEL_W / 2,
            panelY + panelH - FOOTER_H + (FOOTER_H - 8) / 2,
            GRAY
        );

        super.method_25394(ctx, mx, my, delta);
    }

    @Override
    public boolean method_25402(class_11909 click, boolean focused) {
        int mx = (int) click.comp_4798();
        int my = (int) click.comp_4799();
        if (click.method_74245() != 0) return super.method_25402(click, focused);
        int ry = panelY + HEADER_H + ROW_PAD;
        for (Row row : rows) {
            if (my >= ry && my < ry + ROW_H) {
                row.onClick(mx, my, panelX, ry, PANEL_W);
                if (row instanceof SliderRow sr) {
                    draggedSlider = sr;
                    draggedSliderY = ry;
                }
                return true;
            }
            ry += ROW_H + ROW_PAD;
        }
        return super.method_25402(click, focused);
    }

    @Override
    public boolean method_25406(class_11909 click) {
        draggedSlider = null;
        return super.method_25406(click);
    }

    @Override
    public boolean method_25403(class_11909 click, double offsetX, double offsetY) {
        if (click.method_74245() == 0 && draggedSlider != null) {
            draggedSlider.onClick(
                (int) click.comp_4798(),
                draggedSliderY,
                panelX,
                draggedSliderY,
                PANEL_W
            );
            return true;
        }
        return super.method_25403(click, offsetX, offsetY);
    }

    @Override
    public boolean method_25401(
        double mx,
        double my,
        double hScroll,
        double vScroll
    ) {
        int ry = panelY + HEADER_H + ROW_PAD;
        for (Row row : rows) {
            if (my >= ry && my < ry + ROW_H) {
                row.onScroll((int) mx, (int) my, vScroll, panelX, ry, PANEL_W);
                return true;
            }
            ry += ROW_H + ROW_PAD;
        }
        return super.method_25401(mx, my, hScroll, vScroll);
    }

    @Override
    public boolean method_25404(class_11908 input) {
        if (input.comp_4795() == 256) {
            method_25419();
            return true;
        }
        return super.method_25404(input);
    }

    @Override
    public void method_25419() {
        MotionBlurConfig.save(config);
        if (field_22787 != null) field_22787.method_1507(parent);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private String blurTypeName() {
        return switch (config.blurType) {
            case 1 -> "Accumulation [recommended]";
            case 2 -> "Velocity";
            case 3 -> "Velocity (Gaussian)";
            default -> "Unknown";
        };
    }

    private void cycleBlurType() {
        config.blurType = (config.blurType % 3) + 1;
    }

    // ---- Drawing helpers ----

    private static void drawRoundedRect(
        class_332 ctx,
        int x,
        int y,
        int w,
        int h,
        int r,
        int color
    ) {
        ctx.method_25294(x + r, y, x + w - r, y + h, color);
        ctx.method_25294(x, y + r, x + r, y + h - r, color);
        ctx.method_25294(x + w - r, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            int xOff =
                r -
                (int) Math.round(
                    Math.sqrt((double) r * r - (double) (r - i) * (r - i))
                );
            ctx.method_25294(x + xOff, y + i, x + w - xOff, y + i + 1, color);
            ctx.method_25294(x + xOff, y + h - i - 1, x + w - xOff, y + h - i, color);
        }
    }

    private static void drawRoundedBorder(
        class_332 ctx,
        int x,
        int y,
        int w,
        int h,
        int r,
        int color
    ) {
        ctx.method_25294(x + r, y, x + w - r, y + 1, color);
        ctx.method_25294(x + r, y + h - 1, x + w - r, y + h, color);
        ctx.method_25294(x, y + r, x + 1, y + h - r, color);
        ctx.method_25294(x + w - 1, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            int xOff =
                r -
                (int) Math.round(
                    Math.sqrt((double) r * r - (double) (r - i) * (r - i))
                );
            int xOffNext =
                r -
                (int) Math.round(
                    Math.sqrt(
                        (double) r * r - (double) (r - i - 1) * (r - i - 1)
                    )
                );
            ctx.method_25294(x + xOff, y + i, x + xOffNext + 1, y + i + 1, color);
            ctx.method_25294(
                x + w - xOffNext - 1,
                y + i,
                x + w - xOff,
                y + i + 1,
                color
            );
            ctx.method_25294(
                x + xOff,
                y + h - i - 1,
                x + xOffNext + 1,
                y + h - i,
                color
            );
            ctx.method_25294(
                x + w - xOffNext - 1,
                y + h - i - 1,
                x + w - xOff,
                y + h - i,
                color
            );
        }
    }

    private static void drawBorderRect(
        class_332 ctx,
        int x,
        int y,
        int w,
        int h,
        int color
    ) {
        ctx.method_25294(x, y, x + w, y + 1, color);
        ctx.method_25294(x, y + h - 1, x + w, y + h, color);
        ctx.method_25294(x, y, x + 1, y + h, color);
        ctx.method_25294(x + w - 1, y, x + w, y + h, color);
    }

    // ---- Row types ----

    interface Row {
        void render(class_332 ctx, int px, int ry, int pw, int mx, int my);

        default void onClick(int mx, int my, int px, int ry, int pw) {}

        default void onScroll(
            int mx,
            int my,
            double scroll,
            int px,
            int ry,
            int pw
        ) {}
    }

    private class SectionRow implements Row {

        private final String label;

        SectionRow(String label) {
            this.label = label;
        }

        @Override
        public void render(
            class_332 ctx,
            int px,
            int ry,
            int pw,
            int mx,
            int my
        ) {
            ctx.method_25303(
                field_22793,
                label,
                px + SIDE_PAD,
                ry + (ROW_H - 8) / 2,
                GRAY
            );
        }
    }

    private class ToggleRow implements Row {

        private final String label;
        private final java.util.function.BooleanSupplier getter;
        private final java.util.function.Consumer<Boolean> setter;

        ToggleRow(
            String label,
            java.util.function.BooleanSupplier getter,
            java.util.function.Consumer<Boolean> setter
        ) {
            this.label = label;
            this.getter = getter;
            this.setter = setter;
        }

        @Override
        public void render(
            class_332 ctx,
            int px,
            int ry,
            int pw,
            int mx,
            int my
        ) {
            boolean val = getter.getAsBoolean();
            boolean hovered =
                mx >= px && mx < px + pw && my >= ry && my < ry + ROW_H;
            if (hovered) ctx.method_25294(px, ry, px + pw, ry + ROW_H, ROW_HOVER);
            ctx.method_25303(
                field_22793,
                label,
                px + SIDE_PAD,
                ry + (ROW_H - 8) / 2,
                val ? YELLOW : WHITE
            );

            int cbX = px + pw - SIDE_PAD - 9;
            int cbY = ry + (ROW_H - 9) / 2;
            ctx.method_25294(cbX, cbY, cbX + 9, cbY + 9, val ? YELLOW : 0xFF1A1A1A);
            drawBorderRect(ctx, cbX, cbY, 9, 9, val ? YELLOW : CHECK_OFF);
        }

        @Override
        public void onClick(int mx, int my, int px, int ry, int pw) {
            setter.accept(!getter.getAsBoolean());
        }
    }

    private class CycleRow implements Row {

        private final String label;
        private final java.util.function.Supplier<String> valueGetter;
        private final Runnable cycler;

        CycleRow(
            String label,
            java.util.function.Supplier<String> valueGetter,
            Runnable cycler
        ) {
            this.label = label;
            this.valueGetter = valueGetter;
            this.cycler = cycler;
        }

        @Override
        public void render(
            class_332 ctx,
            int px,
            int ry,
            int pw,
            int mx,
            int my
        ) {
            boolean hovered =
                mx >= px && mx < px + pw && my >= ry && my < ry + ROW_H;
            if (hovered) ctx.method_25294(px, ry, px + pw, ry + ROW_H, ROW_HOVER);
            ctx.method_25303(
                field_22793,
                label,
                px + SIDE_PAD,
                ry + (ROW_H - 8) / 2,
                YELLOW
            );
            String val = "< " + valueGetter.get() + " >";
            ctx.method_25303(
                field_22793,
                val,
                px + pw - SIDE_PAD - field_22793.method_1727(val),
                ry + (ROW_H - 8) / 2,
                WHITE
            );
        }

        @Override
        public void onClick(int mx, int my, int px, int ry, int pw) {
            cycler.run();
        }
    }

    private class SliderRow implements Row {

        private final String label;
        private final java.util.function.Supplier<Float> getter;
        private final java.util.function.Consumer<Float> setter;
        private final float min;
        private final float max;
        private final boolean isInt;

        SliderRow(
            String label,
            java.util.function.Supplier<Float> getter,
            java.util.function.Consumer<Float> setter,
            float min,
            float max,
            boolean isInt
        ) {
            this.label = label;
            this.getter = getter;
            this.setter = setter;
            this.min = min;
            this.max = max;
            this.isInt = isInt;
        }

        @Override
        public void render(
            class_332 ctx,
            int px,
            int ry,
            int pw,
            int mx,
            int my
        ) {
            boolean hovered =
                mx >= px && mx < px + pw && my >= ry && my < ry + ROW_H;
            if (hovered) ctx.method_25294(px, ry, px + pw, ry + ROW_H, ROW_HOVER);
            ctx.method_25303(
                field_22793,
                label,
                px + SIDE_PAD,
                ry + (ROW_H - 8) / 2,
                WHITE
            );

            float val = getter.get();
            String valStr = isInt
                ? String.valueOf(Math.round(val))
                : String.format("%.2f", val);

            int sliderX = px + pw - SIDE_PAD - 60;
            int sliderY = ry + (ROW_H - 6) / 2;
            ctx.method_25294(sliderX, sliderY, sliderX + 60, sliderY + 6, 0xFF2A2A2A);
            int fillW = (int) (((val - min) / (max - min)) * 58);
            ctx.method_25294(
                sliderX + 1,
                sliderY + 1,
                sliderX + 1 + fillW,
                sliderY + 5,
                YELLOW
            );
            drawBorderRect(ctx, sliderX, sliderY, 60, 6, 0xFF555555);

            int labelW = field_22793.method_1727(valStr);
            ctx.method_25303(
                field_22793,
                valStr,
                sliderX - labelW - 4,
                ry + (ROW_H - 8) / 2,
                YELLOW
            );
        }

        @Override
        public void onClick(int mx, int my, int px, int ry, int pw) {
            int sliderX = px + pw - SIDE_PAD - 60;
            float t = Math.max(0f, Math.min(1f, (float) (mx - sliderX) / 60f));
            float val = min + t * (max - min);
            if (isInt) val = Math.round(val);
            setter.accept(val);
        }

        @Override
        public void onScroll(
            int mx,
            int my,
            double scroll,
            int px,
            int ry,
            int pw
        ) {
            float step = isInt ? 1f : 0.05f;
            setter.accept(
                Math.max(
                    min,
                    Math.min(max, getter.get() + (float) scroll * step)
                )
            );
        }
    }

    private class ButtonRow implements Row {

        private final String label;
        private final Runnable action;

        ButtonRow(String label, Runnable action) {
            this.label = label;
            this.action = action;
        }

        @Override
        public void render(
            class_332 ctx,
            int px,
            int ry,
            int pw,
            int mx,
            int my
        ) {
            boolean hovered =
                mx >= px && mx < px + pw && my >= ry && my < ry + ROW_H;
            if (hovered) ctx.method_25294(px, ry, px + pw, ry + ROW_H, ROW_HOVER);
            ctx.method_25303(
                field_22793,
                "> " + label,
                px + SIDE_PAD,
                ry + (ROW_H - 8) / 2,
                hovered ? YELLOW : GRAY
            );
        }

        @Override
        public void onClick(int mx, int my, int px, int ry, int pw) {
            action.run();
        }
    }
}
